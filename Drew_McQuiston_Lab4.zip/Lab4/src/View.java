import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.HashMap;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;
/**
 * View: Contains everything about graphics and images
 * Know size of world, which images to load etc
 *
 * has methods to
 * provide boundaries
 * use proper images for direction
 * load images for all direction (an image should only be loaded once!!! why?)
 **/
public class View{
	final static int frameWidth = 500;
    final static int frameHeight = 300;
    final static int imgWidth = 165;
    final static int imgHeight = 165;
    final int frameCount = 10;
    int picNum = 0;
    HashMap<Direction, BufferedImage> fwdImgs;
    HashMap<Direction, BufferedImage[]> fwdPics;
    //The following 3 are primarily handled in Model, but need to also be stored here so that the paint method works properly.
    JFrame frame;
    int xloc;
    int yloc;
    Direction currDirection;

	public int getWidth() {
		return frameWidth;
	}

	public int getHeight() {
		return frameHeight;
	}

	public int getImageWidth() {
		return imgWidth;
	}

	public int getImageHeight() {
		return imgHeight;
	}
	
	public View() {
		//Load image files
		loadImgs();
		
		//Initialize window
		frame = new JFrame();
    	frame.getContentPane().add(new JPanel() {
    		//Override paint method to display the next frame. The right image is chosen using the current direction.
    		//The correct direction, xloc, and yloc are updated just before this method call.
    		@Override
    		public void paint(Graphics g) {
    			g.drawImage(fwdPics.get(currDirection)[picNum], xloc, yloc, Color.gray, this);
    		}
    	});
    	frame.setBackground(Color.gray);
    	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	frame.setSize(frameWidth, frameHeight);
    	frame.setVisible(true);
	}
	
	private void loadImgs() {
		//Find all files in image folder
    	String address = "images/orc/";
    	File folder = new File(address);
    	File[] listOfFiles = folder.listFiles();
    	
    	fwdImgs = new HashMap<>();
    	fwdPics = new HashMap<>();
    	
    	//Look through all image files to find ones containing forward animations
    	//Store images in HashMap fwdImgs with Direction as key for ease of accessing later
    	for (File f : listOfFiles) {
    		if (f.getName().contains("forward")) {
    			if (f.getName().contains("northeast")) {
    				fwdImgs.put(Direction.NORTHEAST, createImage(address+f.getName()));
    				fwdPics.put(Direction.NORTHEAST, new BufferedImage[10]);
    			}
    			else if (f.getName().contains("southeast")) {
    				fwdImgs.put(Direction.SOUTHEAST, createImage(address+f.getName()));
    				fwdPics.put(Direction.SOUTHEAST, new BufferedImage[10]);
    			}
    			else if (f.getName().contains("southwest")) {
    				fwdImgs.put(Direction.SOUTHWEST, createImage(address+f.getName()));
    				fwdPics.put(Direction.SOUTHWEST, new BufferedImage[10]);
    			}
    			else if (f.getName().contains("northwest")) {
    				fwdImgs.put(Direction.NORTHWEST, createImage(address+f.getName()));
    				fwdPics.put(Direction.NORTHWEST, new BufferedImage[10]);
    			}
    			else if (f.getName().contains("north")) {
    				fwdImgs.put(Direction.NORTH, createImage(address+f.getName()));
    				fwdPics.put(Direction.NORTH, new BufferedImage[10]);
    			}
    			else if (f.getName().contains("east")) {
    				fwdImgs.put(Direction.EAST, createImage(address+f.getName()));
    				fwdPics.put(Direction.EAST, new BufferedImage[10]);
    			}
    			else if (f.getName().contains("south")) {
    				fwdImgs.put(Direction.SOUTH, createImage(address+f.getName()));
    				fwdPics.put(Direction.SOUTH, new BufferedImage[10]);
    			}
    			else if (f.getName().contains("west")) {
    				fwdImgs.put(Direction.WEST, createImage(address+f.getName()));
    				fwdPics.put(Direction.WEST, new BufferedImage[10]);
    			}
    		}
    	}
    	
    	//Loop through loaded images and create subImages in fwdPics
    	for (Map.Entry<Direction, BufferedImage[]> b : fwdPics.entrySet()) {
    		BufferedImage temp = fwdImgs.get(b.getKey());
    		for(int i = 0; i < frameCount; i++) {
        		b.getValue()[i] = temp.getSubimage(imgWidth*i, 0, imgWidth, imgHeight);
    		}
    	}
	}
	
	public void update(int x, int y, Direction d) {
		//Update x, y, and direction after updating in Model, so that paint method works properly
		xloc = x;
		yloc = y;
		currDirection = d;
		//Increment frame then repaint
		picNum = (picNum + 1) % frameCount;
		frame.repaint();
		//Delay so that animation is visible
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	private BufferedImage createImage(String fileName){ //Load and return an image file given the filename
    	BufferedImage bufferedImage;
    	try {
    		bufferedImage = ImageIO.read(new File(fileName));
    		return bufferedImage;
    	} catch (IOException e) {
    		e.printStackTrace();
    	}
    	return null;
    }
	
	
}