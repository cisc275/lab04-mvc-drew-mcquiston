import java.awt.Color;

/**
 * Model: Contains all the state and logic
 * Does not contain anything about images or graphics, must ask view for that
 *
 * has methods to
 *  detect collision with boundaries
 * decide next direction
 * provide direction
 * provide location
 **/
public class Model{
	int xloc;
    int yloc;
	Direction currDirection;
	final int xIncr = 8;
    final int yIncr = 2;
    //The following two are for ease of incrementing the position given Ordinal from the direction
	final int xIncrs[] = {0, xIncr, xIncr, xIncr, 0, -xIncr, -xIncr, -xIncr};
	final int yIncrs[] = {-yIncr, -yIncr, 0, yIncr, yIncr, yIncr, 0, -yIncr};
	
	static int frameWidth;
    static int frameHeight;
    static int imgWidth;
    static int imgHeight;
	
	public Model(int frameWidth, int frameHeight, int imgWidth, int imgHeight) {//Initialize attributes
		this.frameWidth = frameWidth;
		this.frameHeight = frameHeight;
		this.imgWidth = imgWidth;
		this.imgHeight = imgHeight;
		
		currDirection = Direction.SOUTHEAST;
		xloc = 0;
		yloc = 0;
	}
	
	public int getX() {
		return xloc;
	}
	
	public int getY() {
		return yloc;
	}

	public Direction getDirect() {
		return currDirection;
	}
	
	public void updateLocationAndDirection() {
		//Increment the position given the current direction
		xloc += xIncrs[currDirection.ordinal()];
		yloc += yIncrs[currDirection.ordinal()];
		checkBoundaries();
	}
	
	//Check to see if orc has moved out of bounds, and if so, correct position and change direction appropriately
	private void checkBoundaries() {
		//Start by checking top boundary. Have to include cases where crosses top and side boundaries in same frame.
		if (yloc < 0) {
			yloc += 2*yIncr;
			switch (currDirection){
			case NORTHEAST:
				if (xloc > frameWidth-imgWidth) {
					currDirection = Direction.SOUTHWEST;
					xloc -= 2*xIncr;
				}
				else currDirection = Direction.SOUTHEAST;
				break;
			case NORTHWEST:
				if (xloc < 0) {
					currDirection = Direction.SOUTHEAST;
					xloc += 2*xIncr;
				}
				else currDirection = Direction.SOUTHWEST;
				break;
			default: currDirection = Direction.SOUTH;
			}
		}
		//Check bottom boundary. Have to include cases where crosses bottom and side boundaries in same frame.
		else if (yloc > frameHeight-imgHeight) {
			yloc -= 2*yIncr;
			switch (currDirection){
			case SOUTHEAST:
				if (xloc > frameWidth-imgWidth) {
					currDirection = Direction.NORTHWEST;
					xloc -= 2*xIncr;
				}
				else currDirection = Direction.NORTHEAST;
				break;
			case SOUTHWEST:
				if (xloc < 0) {
					currDirection = Direction.NORTHEAST;
					xloc += 2*xIncr;
				}
				else currDirection = Direction.NORTHWEST;
				break;
			default: currDirection = Direction.NORTH;
			}
		}
		
		//Check left boundary. All corner cases should be covered above so this one is simpler.
		else if (xloc < 0) {
			xloc += 2*xIncr;
			switch(currDirection) {
			case NORTHWEST:
				currDirection = Direction.NORTHEAST;
				break;
			case SOUTHWEST:
				currDirection = Direction.SOUTHEAST;
				break;
			default: currDirection = Direction.EAST;
			}
		}
		
		//Check right boundary. This one is also simpler.
		else if (xloc > frameWidth-imgWidth) {
			xloc -= 2*xIncr;
			switch(currDirection) {
			case NORTHEAST:
				currDirection = Direction.NORTHWEST;
				break;
			case SOUTHEAST:
				currDirection = Direction.SOUTHWEST;
				break;
			default: currDirection = Direction.WEST;
			}
		}
	}
}